export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCu9B3a-USiPB571j9C1jRhOKbFtTXA9SI",
    authDomain: "upkeepcloud.firebaseapp.com",
    databaseURL: "https://upkeepcloud.firebaseio.com",
    projectId: "upkeepcloud",
    storageBucket: "upkeepcloud.appspot.com",
    messagingSenderId: "36085283940",
    appId: "1:36085283940:web:6d2b7e37df5e73beef7371",
    measurementId: "G-Y7HQECGJ5H"
  }
};
